import java.net.*;
import java.io.*;
import java.util.*;

class DateServer
{
	public static void main(String args[])throws UnknownHostException,IOException
	{	
		ServerSocket ss=new ServerSocket(50710);
		System.out.println("Server started , waiting for client connection.....");
		Socket s=ss.accept();
		System.out.println("Client connected");
		
		DataOutputStream dos=new DataOutputStream(s.getOutputStream());
		dos.writeUTF("Server date: "+(new Date()).toString()+"");
		
		System.out.println("Server closed");
		dos.close();		
		s.close();

	}	
}
