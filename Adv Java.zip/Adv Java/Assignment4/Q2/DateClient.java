import java.net.*;
import java.io.*;

class DateClient
{
	public static void main(String args[])throws UnknownHostException,IOException
	{
		Socket s=new Socket("localhost",50710);
		BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream()));
		System.out.println("Server date and time is :"+in.readLine());
		System.out.println("Client closed");
		s.close();	
	}
}
