import java.net.*;
import java.io.*;

class Myclient
{
	public static void main(String args[])throws UnknownHostException,IOException
	{
		Socket s=new Socket("localhost",50710);
		System.out.println("InetAddres associated with the socket ="+s.getInetAddress());
		System.out.println("Port to which socket is connected ="+s.getPort());
		System.out.println("Local Port to which socket is connected ="+s.getLocalPort());
		System.out.println("Client closed");
		s.close();	
	}
}
