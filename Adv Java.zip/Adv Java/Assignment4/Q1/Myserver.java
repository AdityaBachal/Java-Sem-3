import java.net.*;
import java.io.*;

class Myserver
{
	public static void main(String args[])throws UnknownHostException,IOException
	{	
		ServerSocket ss=new ServerSocket(50710);
		System.out.println("Server started , waiting for client connection.....");
		Socket s=ss.accept();
		System.out.println("Client connected");
		System.out.println("Server closed");
		s.close();

	}	
}
