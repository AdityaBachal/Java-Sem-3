import java.net.*;
import java.io.*;


class MsgServer
{
	public static void main(String args[])throws UnknownHostException,IOException
	{	
		ServerSocket ss=new ServerSocket(50710);
		System.out.println("Server started , waiting for client connection.....");
		Socket s=ss.accept();
		System.out.println("Client connected");
		BufferedReader br=new BufferedReader(new InputStreamReader(s.getInputStream()));
		PrintStream ps=new PrintStream(s.getOutputStream());
		String file_name=br.readLine();
		File f=new File(file_name);
		if(f.exists())
		{
			FileInputStream fin=new FileInputStream(file_name);
			BufferedReader br1=new BufferedReader(fin);
			String st,rs="";
			while((st=br.readLine())!=null)
			{
				ps.println(st);
				System.out.println(st);
			}
			fin.close();
		}	
		else
		{
			ps.println("File not found!");
		}
		
		System.out.println("Server closed");
		ss.close();		
		s.close();
		
	}	
}
