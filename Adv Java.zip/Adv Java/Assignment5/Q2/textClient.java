import java.net.*;
import java.io.*;

class MsgClient
{
	public static void main(String args[])throws UnknownHostException,IOException
	{
		Socket s=new Socket("localhost",50710);
		System.out.println("Client connected...");
		BufferedReader br=new BufferedReader(new InputStreamReader(s.getInputStream()));
		BufferedReader br1=new BufferedReader(new InputStreamReader(System.in));
		PrintStream ps=new PrintStream(s.getOutputStream());
		System.out.println("Enter file name: ");
		String file_name=br1.readLine();
		ps.println(file_name);
		String s;
		s=br.readLine();
		while(s!=null)
		{
			System.out.println(s);	
			s=br.readLine();
		
		}
		System.out.println("Server closed...");				
		s.close();	
	}
}
