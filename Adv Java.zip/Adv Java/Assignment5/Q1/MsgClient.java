import java.net.*;
import java.io.*;

class MsgClient
{
	public static void main(String args[])throws UnknownHostException,IOException
	{
		Socket s=new Socket("localhost",50710);
		System.out.println("Client connected...");
		BufferedReader br=new BufferedReader(new InputStreamReader(s.getInputStream()));
		BufferedReader br1=new BufferedReader(new InputStreamReader(System.in));
		PrintStream ps=new PrintStream(s.getOutputStream());
		String str;
		System.out.println("Enter the message:");
		while(!(str=br1.readLine()).equalsIgnoreCase("END"))
		{
			ps.println(str);
			System.out.println("Enter any string:");
		}
		System.out.println("Client closed");
		ps.close();		
		s.close();	
	}
}
