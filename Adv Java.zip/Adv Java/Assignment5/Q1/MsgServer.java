import java.net.*;
import java.io.*;
import java.util.*; 

class MsgServer
{
	public static void main(String args[])throws UnknownHostException,IOException
	{	
		ServerSocket ss=new ServerSocket(50710);
		System.out.println("Server started , waiting for client connection.....");
		Socket s=ss.accept();
		System.out.println("Client connected");
		BufferedReader br=new BufferedReader(new InputStreamReader(s.getInputStream()));
		//PrintStream ps=new PrintStream(s.getOutputStream());
		String str;
		while((str=br.readLine())!=null)
		{
			System.out.println(str);
		}	
		System.out.println("Server closed");
				
		s.close();
		//ps.close();

	}	
}
